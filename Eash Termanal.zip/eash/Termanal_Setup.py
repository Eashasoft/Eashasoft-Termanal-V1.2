import os
import subprocess

print("Welcome to the Eash Termanal Setup")
print("Please enter 'setup' into the input below to begin")

def inputbox():
    input_in = input("> ")

    if input_in == "setup":
        setup_confirm = input("Start the setup process? (Y/N)")

        if setup_confirm == "Y" or setup_confirm == "y":
            subprocess.run(r"files\installextentions.bat")
            inputbox()
        if setup_confirm == "n" or setup_confirm == "n":
            inputbox()
inputbox()
